package example1;

import java.util.List;

import shipping.IContainer;
import shipping.IShip;

public class Ship implements IShip {

	@Override
	public List<IContainer> containers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<IContainer> offload() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRegistration() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setRegistration(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addContainer(IContainer container) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printDetails() {
		// TODO Auto-generated method stub
		
	}

}

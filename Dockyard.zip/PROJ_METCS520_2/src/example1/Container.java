package example1;

import shipping.IContainer;

public class Container implements IContainer {

	@Override
	public String id() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String description() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String destinationCity() {
		// TODO Auto-generated method stub
		return null;
	}

}

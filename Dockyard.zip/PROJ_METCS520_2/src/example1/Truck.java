package example1;

import shipping.IContainer;
import shipping.ITruck;

public class Truck implements ITruck {

	@Override
	public String registration() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String destinationCity() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addContainer(IContainer container) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public IContainer offloadContainer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasContainer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void printDetails() {
		// TODO Auto-generated method stub
		
	}

}
